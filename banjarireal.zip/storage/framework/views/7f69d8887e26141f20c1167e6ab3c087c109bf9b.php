

<table id="" class="table-bordered" cellspacing="0" width="100%">
    <thead>
    <tr class="bg-info">
        <th class="text-center">Id#</th>
        <th class="text-center">Enquiry#</th>
        <th class="text-center">Category</th>
        <th class="text-center">Name</th>
        <th class="text-center">Contact Info</th>
        <th class="text-center">Created On</th>
        <th class="text-center">Last Visited</th>
        <th class="text-center">Next Followup Date</th>
        <th class="text-center">Status</th>
        <th class="text-center">Allocated To</th>
        <th class="text-center">Operations</th>
    </tr>
    </thead>
    <tbody>
    <?php $counter = 1; ?>
    <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="<?php echo e(($item->is_completed == 1 && $item->is_converted == 1) ? 'bg-success' : ''); ?> text-center">
            <td><?php echo e($item->id); ?></td>
            <td><?php echo e($item->enquiry_master->full_enquiry_no); ?></td>
            <td><?php if($item->enquiry_master->enquiry_category_id != null): ?><?php echo e($item->enquiry_master->enquiry_category->category_name); ?><?php else: ?>
                    - <?php endif; ?></td>
            <td title="Remark- <?php echo e($item->enquiry_master->any_requirement); ?>"><?php echo e($item->name); ?></td>
            <td><?php echo e($item->contact); ?>, <?php echo e($item->email); ?>, <?php echo e(is_null($item->address)? " - " : $item->address); ?></td>
            <td><?php echo e(($item->created_date == null)? " - " :  date_format(date_create($item->created_date),"d-M-Y h:i A")); ?></td>
            <td><?php echo e(($item->last_visited_date == null)? " - " : date_format(date_create($item->last_visited_date), "d-M-Y")); ?></td>
            <td><?php echo e(($item->next_followup_date == null)? " - " : date_format(date_create($item->next_followup_date), "d-M-Y")); ?></td>
            <td><?php echo e(($item->lead_status_id == null)? " - " : $item->lead_status->status); ?></td>
            <td><?php echo e(($item->user_master_id != null)? $item->user_master->name :  " - "); ?></td>

            <td id="<?php echo e($item->id); ?>">
                <?php if($item->is_completed == 0 & $role_master_id == 1): ?>
                    <a href="#" class="btn-sm btn-danger btn-xs glyphicon glyphicon-eye-close delete_lead"
                       title="Close Lead" onclick="close_lead(this);" ></a>
                    
                    
                    
                    
                <?php endif; ?>
                
                
                <a id="<?php echo e($item->enquiry_master_id); ?>" class="btn-sm btn-info btn-xs glyphicon glyphicon-eye-open view-enquiry_" onclick="view_inquiry(this);" title="View Enquiry"></a>
                <a href="tour/<?php echo e($item->id); ?>/create" class="btn-sm btn-info btn-xs glyphicon glyphicon-plus"
                   title="Generate Tour">
                </a>
                <a class=" btn-sm btn-success btn-xs glyphicon glyphicon-comment view-comment"
                   title="View Communication" onclick="getCommunication(<?php echo e($item->id); ?>);"><strong></strong></a>
                <a href="#" id="<?php echo e($item->enquiry_master_id); ?>" onclick="edit_inquiry(this);"
                   class="btn-sm btn-success btn-xs edit-enquiry_ glyphicon glyphicon-pencil"
                   title="Edit Enquiry"></a>
                
                <?php if($_SESSION['user_master']->role_master_id == 1): ?>
                    <a href="#" class="btn-sm btn-primary assign btn-xs glyphicon glyphicon-share-alt"
                       data-toggle="modal" onclick="assign_to_executive(this);" title="Assign To Executive"></a>
                <?php else: ?>
                    <a href="#" class="btn-sm btn-primary btn-xs glyphicon glyphicon-cloud btnFollowUp"
                       title="Need Followup" onclick="getfollowup(<?php echo e($item->id); ?>);">
                    </a>
                    <a href="#" class="btn-sm btn-success btn-xs glyphicon glyphicon-check btnConvert"
                       title="Converted" onclick="getConverted(<?php echo e($item->id); ?>);">
                    </a>
                    <a href="#" class="btn-sm btn-danger btn-xs glyphicon glyphicon-cloud btnNoReponse"
                       title="No Response" onclick="getNoResponse(<?php echo e($item->id); ?>);">
                    </a>
                <?php endif; ?>
                <?php if($item->is_itinerary_created == 1): ?>
                    <a href="tour/<?php echo e($item->id); ?>/itinerary_by_lead"
                       class="btn-sm btn-primary btn-xs glyphicon glyphicon-italic"
                       title="View Itinerary Tour"></a>
                <?php endif; ?>

                
            </td>
        </tr>
        <?php $counter++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<input type="hidden" id="btn_id" value="<?php echo e($btn); ?>"/>
<input type="hidden" id="pageno" value="<?php echo e($pageno); ?>"/>
<input type="hidden" id="total" value="<?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount($btn)); ?>"/>

<script>
    function getmorepost() {
        cp = 20;
        cp += parseFloat($('#pageno').val());
        $('#pageno').val(cp);
        var btn_id = $('#btn_id').val();
        var send_to_url = '<?php echo e(url('/')); ?>' + "/lead/" + btn_id + "/filter";
        $.ajax({
            type: "get",
            contentType: "application/json; charset=utf-8",
            url: send_to_url,
//                data: '{"currentpage":"' + cp + '", "category_id":"' + category_id + '"}',
            data: {pageno: cp, btn: btn_id},
            
                
            
            success: function (data) {
                $("#leadTable").html(data);
            },
            error: function (xhr, status, error) {
                //alert('Error occurred');
                $("#leadTable").html(xhr.responseText);
            }
        });
    }
    $(document).ready(function () {
        $(window).scroll(function (event) {
            if ($(window).scrollTop() + $(window).height() == $(document).height()) {
                if (parseFloat($('#pageno').val()) <= parseFloat($('#total').val())) {
                    getmorepost();
                }
            }
        });
    });


    function getCommunication(dis) {
        $('#myModal').modal('show');
        $('.modal-title').html('Communication Process');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = dis;
        var editurl = '<?php echo e(url('/')); ?>' + "/lead/" + id + "/add";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
                $('.modal-body').html(xhr.responseText);
                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    }
    
    function assign_to_executive(dis) {
        $('#myModal').modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        $('#myModal .modal-title').html('Assign To Executive');
        var id = $(dis).parent().attr('id');
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_cLeadAssgn')); ?>",
            data: '{"data":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Internet connection failed...Please refresh the page again");
            }
        });
    }

    function edit_inquiry(dis) {
        $('#myModal').modal('show');
        $('.modal-title').html('Edit Enquiry');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = $(dis).attr('id');
        var editurl = '<?php echo e(url('/')); ?>' + "/enquiry/" + id + "/edit";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
//                $('.modal-body').html(xhr.responseText);
                $('.modal-body').html("Internet connection failed...Please refresh the page again");

                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    }
    
    function view_inquiry(dis) {
        $('#myModal').modal('show');
        $('.modal-title').html('View Enquiry Details');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

        var id = $(dis).attr('id');
        var editurl = '<?php echo e(url('/')); ?>' + "/enquiry/" + id;
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
//                $('.modal-body').html(xhr.responseText);

                $('.modal-body').html("Internet connection failed...Please refresh the page again");
                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    }
    
    function close_lead(dis) {
        $('#myModal').modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = $(dis).parent().attr('id');
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_clsLead')); ?>",
            data: '{"data":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Technical Error Occurred");
            }
        });
    }
    
    $(document).ready(function () {
        var table = $('#dataTable').DataTable({
            "columnDefs": [
                {"width": "20px", "targets": 0}
            ],
            "order": [[0, "desc"]]
        });

        $('.datatable-col').on('keyup change', function () {
            table.column($(this).attr('id')).search($(this).val()).draw();
        });
    });

    function getfollowup(dis) {
        $("#myModal").modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = dis;
        $.ajax({
            type: "post",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_gflwupfrm')); ?>",
            data: '{"id":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Error Occurred");
            }
        });
    }

    //    $(".btnConvert").click(function () {
    function getConverted(dis) {
        $("#myModal").modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = dis;
        $.ajax({
            type: "post",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_gCnvtFrm')); ?>",
            data: '{"id":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Error Occurred");
            }
        });

    }

    //    $(".btnNoReponse").click(function () {
    function getNoResponse(dis) {
        $("#myModal").modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = dis;
        $.ajax({
            type: "post",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_gNRF')); ?>",
            data: '{"id":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Error Occurred");
            }
        });
    }

</script>
