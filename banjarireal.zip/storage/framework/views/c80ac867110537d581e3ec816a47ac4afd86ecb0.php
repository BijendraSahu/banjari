<?php $__env->startSection('title','List of Itineraries'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .bigdropdown {
            width: 100% !important;
        }
    </style>
    <h3 class="heading bg-success">Create Tour Planning</h3>
    <hr/>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <?php echo Form::open(['url' => 'event', 'class' => 'form-horizontal', 'id'=>'event']); ?>

    <div class="container-fluid">
        <div class="col-sm-6">
            <h3 class="bg-info text-center">Basic Info</h3>
            <p class="clearfix"></p>
            <div class='form-group'>
                <?php echo Form::label('name', 'Category*', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::text('tour_info_id', $id, ['class' => 'form-control hidden input-sm required', 'placeholder'=>'Tour Name']); ?>

                    <select class="form-control category" name="category" id="category">
                        <option value="Activity">Activity</option>
                        <option value="Lodging">Lodging</option>
                        <option value="Transportation">Transportation</option>
                        <option value="Other Info">Other Info</option>
                    </select>
                </div>
            </div>
            <div class='form-group'>
                <?php echo Form::label('type', 'Type *', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-5'>
                    <p id="type1">
                        <select class="form-control" name="type">
                            <option value="Check-in">Check-in</option>
                            <option value="Check-out">Check-out</option>
                        </select>
                    </p>

                    
                    
                    
                    
                    

                    
                        
                            
                            
                        
                    
                </div>
                <div class='col-sm-4'>
                    <?php echo Form::text('time', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Time']); ?>


                </div>
            </div>
            <div class='form-group'>
                <?php echo Form::label('title', 'Title *', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::text('title', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Title']); ?>

                </div>
            </div>
            <div class='form-group'>
                <?php echo Form::label('notes', 'Notes', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::text('notes', null, ['class' => 'form-control input-sm', 'placeholder'=>'Notes']); ?>

                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h3 class="bg-info text-center">Other Info</h3>
            
            
            
            
            
            
            <div class='form-group'>
                <?php echo Form::label('duration', 'Duration', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::text('duration', null, ['class' => 'form-control input-sm', 'placeholder'=>'Duration']); ?>

                </div>
            </div>
            <div class="form-group">
                <?php echo Form::label('vehicle_master_id', 'Vehicle *', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::select('vehicle_master_id', $vehicles, null,['class' => 'form-control requiredDD']); ?>

                </div>
            </div>
            <div class="form-group">
                <?php echo Form::label('hotel_master_id', 'Hotel', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::select('hotel_master_id', $hotels, null,['class' => 'typeDD bigdropdown hotel-dd', 'id'=>'hotel_master_id']); ?>

                </div>
            </div>
            
            
            
            
            
            
            <div class='form-group'>
                <?php echo Form::label('hotel_info_id', 'Select Rooms', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-10'>
                    <div id='chkBoxContainer'>

                    </div>
                </div>
            </div>

        </div>
        <div class='form-group'>
            <div class='col-sm-offset-6 col-sm-6'>
                <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary btn-block']); ?>

            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

    

    
    <script>

        $(function () {
            $(".typeDD").select2({
//            placeholder: "SELECT IMEI",
                dropdownAutoWidth : 'true',
                width: 'auto',
                cache: true
            });
        });

        $(document).ready(function () {
            $(".hotel-dd").val('0');

        });

        
    
    
    
    
    
            
            
                
                
                
                
                
                    
                    
                    
                    
                    
                        
                    
                    
                
                
                    
                
            
    
        

    $(".hotel-dd").change(function () {
            var id = $("#hotel_master_id").val();
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_groom')); ?>",
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#chkBoxContainer').html(data);
                },
                error: function (xhr, status, error) {
                    alert('xhr.responseText');
                }
            });
        });
        $(function () {
            $('.dtp').datepicker({
                format: "dd-MM-yyyy",
//            maxViewMode: 5,
                todayBtn: "linked",
                daysOfWeekHighlighted: "0",
                autoclose: true,
                todayHighlight: true
            });
        });
//        $(function() {
//            $('#type1').hide();
//            $('#type2').hide();
//            $('#category').change(function(){
//                if($("#category").val() == 'Transportation') {
//                    $('#type2').show();
//                    $('#type1').hide();
//                } else {
//                    $('#type1').show();
//                    $('#type2').hide();
//                }
//            });
//        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>