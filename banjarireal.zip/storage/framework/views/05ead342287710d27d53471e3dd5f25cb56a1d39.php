<?php $__env->startSection('title','Create Tour'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .bigdropdown {
            width: 100% !important;
        }
    </style>
    <a href="<?php echo e(url('tour')); ?>" class="btn btn-sm bg-danger btn-primary add-tour btnSet pull-right">
        <span class="fa fa-eye"></span>&nbsp;Tour List</a>
    <h3 class="heading bg-success">Create Tour</h3>
    <hr/>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php echo Form::open(['url' => 'tour', 'class' => 'form-horizontal', 'id'=>'tour', 'files'=>true]); ?>

    <div class="container-fluid">
        <div class="form-group">
            <?php echo Form::label('lead_master_id', 'Lead Name *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-9'>
                <?php echo Form::select('lead_master_id', $leads, $lead_id,['class' => 'typeDD bigdropdown lead-dd', 'id'=>'lead_master_id']); ?>

            </div>
        </div>
        <p class="clearfix"></p>
        <div class='form-group'>
            <?php echo Form::label('name', 'Tour Name *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-9'>
                <?php echo Form::text('tour_name', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Tour Name']); ?>

            </div>
        </div>
        <div class='form-group'>
            <?php echo Form::label('start_date', 'Start Date *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-9'>
                <?php echo Form::text('start_date',$enq_info ? date_format(date_create($enq_info->enquiry_master->travel_date),'d-M-Y'): null, ['class' => 'form-control input-sm dtp required', 'placeholder'=>'Start Date']); ?>

            </div>
        </div>
        <div class='form-group'>
            <?php echo Form::label('end_date', 'End Date *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-9'>
                <?php echo Form::text('end_date', $enq_info ? date_format(date_create($enq_info->enquiry_master->tour_end_date),'d-M-Y'):null, ['class' => 'form-control input-sm dtp required', 'placeholder'=>'End Date']); ?>

            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('tour_image', 'Tour Image*',  ['class' => 'col-sm-2 control-label', 'type'=>'file', 'accept'=>'image/*']); ?>

            <div class="col-sm-9">
                <?php echo Form::file('tour_image', null, ['class' => 'control-label input-sm required', 'type'=>'file', 'accept'=>'image/*']); ?>

            </div>
        </div>

        <div class='form-group'>
            <div class='col-sm-offset-2 col-sm-9'>
                <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

    <script>
        $(function () {
            $('.dtp').datepicker({
                format: "dd-M-yyyy",
//            maxViewMode: 5,
                todayBtn: "linked",
                daysOfWeekHighlighted: "0",
                autoclose: true,
                todayHighlight: true
            });
        });

        $(function () {
            $(".typeDD").select2({
//            placeholder: "SELECT IMEI",
                dropdownAutoWidth: 'true',
                width: 'auto',
                cache: true
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>