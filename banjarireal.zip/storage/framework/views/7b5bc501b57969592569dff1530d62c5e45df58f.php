<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
<?php if($errors->any()): ?>
    <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
<?php endif; ?>
<?php echo Form::open(['url' => 'vehicle', 'class' => 'form-horizontal', 'id'=>'vehicle']); ?>

<div class="container-fluid">
    <div class='form-group'>
        <?php echo Form::label('name', 'Vehicle Name *', ['class' => 'col-sm-2 control-label']); ?>

        <div class='col-sm-9'>
            <?php echo Form::text('vehicle_name', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Vehicle Name']); ?>

        </div>
    </div>
    <div class='form-group'>
        <?php echo Form::label('seat', 'Seat *', ['class' => 'col-sm-2 control-label']); ?>

        <div class='col-sm-9'>
            <?php echo Form::text('seat', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Seat']); ?>

        </div>
    </div>

    <div class='form-group'>
        <?php echo Form::label('rate', 'Rate/KM *', ['class' => 'col-sm-2 control-label']); ?>

        <div class='col-sm-9'>
            <?php echo Form::text('rate', null, ['class' => 'form-control input-sm amount required', 'placeholder'=>'Rate/KM']); ?>

        </div>
    </div>
    <div class='form-group'>
        <div class='col-sm-offset-2 col-sm-9'>
            <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

        </div>
    </div>
</div>
<?php echo Form::close(); ?>

