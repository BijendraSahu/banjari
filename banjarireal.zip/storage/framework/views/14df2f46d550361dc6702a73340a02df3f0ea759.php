<div class="container-fluid">
    <div class="col-sm-6">
        <h3 class="bg-info text-center">Basic Info</h3>
        <p class="clearfix"></p>
        <div class='form-group'>
            <?php echo Form::label('user_no', 'Enquiry No#', ['class' => 'col-sm-5 control-label']); ?>

            <div class='col-sm-7'>
                <label for="" class="badge"><?php echo e($enquiry->full_enquiry_no); ?></label>
            </div>
        </div>
        <p class="clearfix"></p>
        <p class="clearfix"></p>
        <div class='form-group'>
            <?php echo Form::label('user_no', 'Enquiry Category', ['class' => 'col-sm-5 control-label']); ?>

            <div class='col-sm-7'>
                <label for=""><?php if($enquiry->enquiry_category_id != null): ?><?php echo e($enquiry->enquiry_category->category_name); ?><?php else: ?>
                        - <?php endif; ?></label>
            </div>
        </div>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('name', 'Name', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->name); ?></label>
            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('name', 'Contact', ['class'=>'col-sm-5 form-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->contact); ?></label>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('name', 'Email', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->email); ?></label>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('no_of_person', 'No of Person', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->no_of_person); ?></label>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('no_of_child(6-11)', 'No of Child(6-11)', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->no_of_child_above_5); ?></label>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('No of Child(0-5)', 'No of Child(0-5)', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->no_of_child_upto_5); ?></label>

            </div>
        </div>

    </div>
    <div class="col-sm-6">
        <h3 class="bg-info text-center">Traveling Info</h3>
        
        
        
        
        
        

        
        
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('travel_date', 'Travel Date', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e(date_format(date_create( $enquiry->travel_date),'d-M-Y')); ?></label>

            </div>
        </div>
        

        
        
        
        
        

        
        
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('tour_start_from', 'Tour Start From', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->tour_start_from); ?></label>
            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('tour_start_from', 'Departure Destination', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->departure_destination); ?></label>
            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('travel_duration', 'Travel Duration', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->travel_duration); ?></label>
            </div>
        </div>

        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('travel_date', 'Tour End Date', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e(date_format(date_create( $enquiry->tour_end_date),'d-M-Y')); ?></label>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('current_location', 'Current Location', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->current_location); ?></label>
            </div>
        </div>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('any_requirement', 'Remark', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                
                <label for=""><?php echo e($enquiry->any_requirement); ?></label>
            </div>
        </div>

    </div>
</div>