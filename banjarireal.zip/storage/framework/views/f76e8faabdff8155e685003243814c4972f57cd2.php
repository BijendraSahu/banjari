<?php $__env->startSection('title','Create Planning'); ?>

<?php $__env->startSection('content'); ?>
    
    
    <a href="<?php echo e(url('tour')); ?>" class="btn btn-sm bg-danger btnSet btn-primary add-tour btnSet pull-right">
        <span class="fa fa-eye"></span>Back To Tour List</a>
    <h3 class="heading bg-success">Create Tour Planning</h3>
    <hr/>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    

    
    <div class="row">
        <div class="col-sm-4">
            <!--left col-->
            <?php $counter = 1; ?>
            <ul class="list-group">
                <li class="list-group-item text-muted" contenteditable="false"><h4><strong>Trip Information</strong>
                    </h4></li>
                <?php $__currentLoopData = $tour_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="list-group-item text-right" style="font-size: 13px;"><span class="pull-left"><strong
                                    class="">Day <?php echo e($counter); ?> <p
                                        class=""><?php echo e($nameOfDay = date('l', strtotime($info->date))); ?></p></strong></span>
                        
                        <a href="<?php echo e(url('event')); ?>/<?php echo e($info->id); ?>/create" id="<?php echo e($info->id); ?>"
                           class="btn btn-info btn-xs create-">
                            <i class="fa fa-plus"></i>New Event</a>
                        <strong>
                            
                            
                            
                            <a href="#" id="<?php echo e($info->id); ?>" class="a_txt date">
                                <?php echo e(date_format(date_create($info->date), "d-M-Y")); ?> <i
                                        class="fa fa-arrow-right"></i></a>
                        </strong>

                    </li>
                    <?php $counter++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
        <!--/col-3-->


        <div class="col-sm-8" style="" contenteditable="false">
            
            
            

            
            
            <div class="panel panel-default target">
                <div class="panel-heading" contenteditable="false"><h4><?php echo e($tour->tour_name); ?></h4>

                </div>
                <div class="panel-body" id='chkBoxContainer'>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                </div>

            </div>
        </div>


        <div id="push"></div>
    </div>
    <script>

        $(".date").click(function () {
            var id = $(this).attr('id');
            console.log(id);
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gevent')); ?>",
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#chkBoxContainer').html(data);
                },
                error: function (xhr, status, error) {
                    alert('xhr.responseText');
                }
            });
        });

        $(".create-event").click(function () {
            $('#myModal').modal('show');
            $('.modal-title').html('Create Event');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = $(this).attr('id');
            var editurl = "/event/" + id + "/create";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
                    $('.modal-body').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>