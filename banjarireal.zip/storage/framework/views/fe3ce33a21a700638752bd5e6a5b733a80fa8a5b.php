<?php if(count($tour_info_details)): ?>
    <?php $__currentLoopData = $tour_info_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="thumbnail">
                    <div class="caption">
                        <h3 class="bg-info text-center"><?php echo e($details->category); ?></h3>
                        <h4><b>Title: <?php echo e($details->title); ?></b></h4>
                        <h5><p class="badge" style="font-size: 15px;"><?php echo e($details->type); ?></p>
                            By <?php echo e($details->vehicle_master->vehicle_name); ?> <?php echo e($details->vehicle_master->seat); ?>

                            Rs.<?php echo e($details->vehicle_master->rate); ?>

                            <p><b>Notes:</b> <?php echo e($details->notes); ?></p>
                        </h5>
                        <hr>
                        <?php if($details->hotel_master_id != null): ?>
                            <h3 class="text-center">HOTEL:
                                <?php echo e($details->hotel_master->hotel_name); ?>

                            </h3>
                            <table id="dataTable" class="display table">
                                <thead>
                                <tr class="bg-info">
                                    <th>Room Type & Inclusion</th>
                                    <th>Room Rate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tour_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->hotel_info->room_type); ?></td>
                                            <td><i class="fa fa-inr"></i> <?php echo e($item->hotel_info->rate); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div role='alert' id='alert' class='alert alert-danger'>No Event Found In Selected Day</div>
<?php endif; ?>














































