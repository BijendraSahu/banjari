<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
<?php if($errors->any()): ?>
    <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
<?php endif; ?>
<?php echo Form::open(['url' => 'policy', 'class' => 'form-horizontal', 'id'=>'user_master']); ?>

<div class="container-fluid">
    <div class="col-sm-12">
        <div class='form-group'>
            <?php echo Form::label('name', 'Policy *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-10'>
                <?php echo Form::text('policy', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Enter Policy']); ?>

            </div>
        </div>
        <div class='form-group'>
            <div class='col-sm-offset-2 col-sm-10'>
                <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

            </div>
        </div>

    </div>
</div>
<?php echo Form::close(); ?>

