<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
<?php if($errors->any()): ?>
    <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
<?php endif; ?>
<?php echo Form::open(['url' => 'tour/'.$tour->id.'/add_vehicle', 'class' => 'form-horizontal', 'id'=>'hotel']); ?>

<div class="container-fluid">
    <div class="form-group">
        <?php echo Form::label('vehicle_master_id', 'Select Vehicle *', ['class' => 'col-sm-2 control-label']); ?>

        <div class='col-sm-9'>
            <?php echo Form::select('vehicle_master_id', $vehicles, null,['class' => 'form-control requiredDD']); ?>

        </div>
    </div>
    <div class='form-group'>
        <?php echo Form::label('comment', 'Comment', ['class' => 'col-sm-2 control-label']); ?>

        <div class='col-sm-9'>
            <?php echo Form::text('vehicle_comment', null, ['class' => 'form-control input-sm', 'placeholder'=>'Comment']); ?>

        </div>
    </div>
    <div class='form-group'>
        <div class='col-sm-offset-2 col-sm-9'>
            <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

        </div>
    </div>
</div>
<?php echo Form::close(); ?>

