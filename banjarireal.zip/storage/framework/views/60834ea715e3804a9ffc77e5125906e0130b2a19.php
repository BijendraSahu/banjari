<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
<?php if($errors->any()): ?>
    <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
<?php endif; ?>
<?php echo Form::open(['url' => 'tour/'.$tour->id.'/add_inclusion', 'class' => 'form-horizontal', 'id'=>'hotel']); ?>

<div class="container-fluid">
    <div class="form-group">
        <table id="dtTable" class="display table">
            <thead>
            <tr class="bg-info">
                <th>Option</th>
                <th>Select Inclusion Name</th>
                <th>Rate</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $inclusions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox" value="<?php echo e($list->id); ?>" name="inclusion[]"/></td>
                    <td><?php echo e($list->name); ?></td>
                    <td><i class="fa fa-inr"></i> <?php echo e($list->rate); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class='form-group'>
        <div class='col-sm-offset-2 col-sm-9'>
            <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary btn-block']); ?>

        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<script>
    $(document).ready(function () {
        $('#dtTable').DataTable(
            {
                "order": [],
                "columnDefs": [{
                    "targets": 'no-sort',
                    "orderable": false,

                }]
            });
        $('.dtTable').DataTable(
            {
                "order": [],
                "columnDefs": [{
                    "targets": 'no-sort',
                    "orderable": false,

                }],
                //scrollY: '25v',
                //"iDisplayLength": 5,
                "lengthMenu": [5, 10, 25]

            });
    });
</script>
