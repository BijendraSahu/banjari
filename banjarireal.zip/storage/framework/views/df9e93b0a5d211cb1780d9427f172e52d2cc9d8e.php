




<script src="<?php echo e(URL::asset('js/validation.js')); ?>"></script>

    <div>
        
        <?php echo Form::open(['url'=>'lead/'.$lead->id, 'id'=>'frmeditLead','method'=>'PUT']); ?>

        

        <div class="form-group">
            <?php echo Form::label('name', 'Person Name', ['class' => 'col-sm-2 control-label']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('name', $lead->name, ['class' => 'form-control textWithSpace required', 'placeholder'=>'Person Name']); ?>

            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('name', 'Contact', ['class'=>'col-sm-2 form-label']); ?>

            <div class="col-sm-10">
                <?php echo e(Form::text('contact', $lead->contact, ['class' => 'form-control numberOnly required', 'placeholder'=>'Contact'])); ?>

            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('name', 'Email', ['class' => 'col-sm-2 control-label']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('email', $lead->email, ['class' => 'form-control', 'placeholder'=>'Email']); ?>

            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('name', 'Address', ['class' => 'col-sm-2 control-label']); ?>

            <div class="col-sm-10">
                <?php echo Form::text('address', $lead->address, ['class' => 'form-control', 'placeholder'=>'Address']); ?>

            </div>
        </div>

        
            
            
                
            
        

        
            
            
                
                    
                           
                    
                
            
        

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <?php echo e(Form::submit('Update', ['class' => 'btn btn-primary'])); ?>

            </div>
        </div>
    </div>
    <?php echo e(Form::close()); ?>


