<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Itinerary</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">

    <script src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>
    
    <script src="<?php echo e(url('assets/js/jspdf.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/from_html.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/split_text_to_size.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/standard_fonts_metrics.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/html2canvas.js')); ?>"></script>
    <link href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">

</head>

<style>

    @import  url('https://fonts.googleapis.com/css?family=Indie+Flower');

    * {
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        -webkit-box-sizing: border-box;
    }

    body {
        margin: 0 auto;
        font-family: 'Open Sans', sans-serif;
        /*font-size: 16px;*/
        background-color: #FFFFFF;
    }

    .pad20 {
        padding: 10px 20px;
    }

    .wrapper {
        width: 100%;
        margin: 0 auto;
        padding: 20px 1%;
    }

    .nopadding {
        padding: 0px;
    }

    .brdrblck {
        border: solid 1px #000;
    }

    .brdrblue {
        border: solid 5px #231571;
        padding: 0px 22px;
    }

    .cerhead {
        padding: 7px;
        border-bottom: solid thin #000;
        border-top: solid thin #000;
        background: #eae8f9;
        font-size: 26px;
        font-weight: bold;
    }

    .cername {
        font-family: 'Indie Flower', cursive;
        letter-spacing: 5px;
        font-size: 28px;
    }

    .nofont {
        font-size: 16px;
        margin-right: 5px;
    }

    .formstyle {
        outline: none;
        border: none;
        border-bottom: dotted 2px #000;
        border-radius: 0px;
        box-shadow: none;
    }
</style>
<body>
<div class="container-fluid nopadding pad20">
    <div class="wrapper">
        <div class="col-sm-12 brdrblck pad20">
            <div class="col-sm-12 nopadding pad20 brdrblue text-center">
                <h3 class="cerhead">BANJARI TOURS & TRAVELS</h3>
                <p class="clearfix"></p>

                
                <div class="col-xs-12 nopadding">
                    <div class="col-xs-6 text-left"><span class="nofont">Dear Sir/Mam, </span>
                        <span class="nofont"></span>
                        <p class="clearfix"></p>
                        <p class="clearfix"></p>
                        <h5 class="text-left">Greeting from Banjari MP Tours. Thanks for your valuable inquiry. We are
                            pleasure to offer you our best possible quotation for your required itinerary.</h5>
                        <p class="clearfix"></p>
                        <p><b>Enquiry No:</b> <?php echo e($tour->lead_master->enquiry_master->full_enquiry_no); ?></p>
                        <p><b>Travel
                                Date:</b> <?php echo e(date_format(date_create($tour->lead_master->enquiry_master->travel_date), "d-M-Y")); ?>

                        </p>
                        <p><b>No. of Days:</b> <?php echo e($tour->total_days); ?> Days</p>
                        <p><b>Guests traveling:</b> <?php echo e($tour->lead_master->enquiry_master->no_of_person); ?> Person</p>
                        
                        <p class="clearfix"></p>
                        <p class="clearfix"></p>
                    </div>
                    
                    
                    
                </div>
                <h3><?php echo e($tour->tour_name); ?></h3>
                <hr>
                
                <?php if($tour->tour_image != null): ?>
                    <img src="<?php echo e(url($tour->tour_image)); ?>" width="800px" height="400px"/>
                <?php else: ?>
                    <img src="<?php echo e(url('assets/tours/EEPw3H_trip.jpg')); ?>" width="800px" height="400px"/>
                <?php endif; ?>
                <hr>
                <p class="clearfix"></p>
                <h4 class="text-left">Suggested Itinerary: <h5 class="text-left">
                        Please note below is a tentative itinerary for your trip. the actual may vary depending on the
                        inclusions selected in the trip.</h5></h4>
                <p class="clearfix"></p>
                <hr>
                <form class="form-horizontal">
                    <?php $counter = 1; ?>
                    <?php $__currentLoopData = $tour_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <div class="col-sm-12 text-left"><b>Day <?php echo e($counter); ?>:</b>
                                <?php if($details->sentence_master_id != null): ?><?php echo e($details->sentence_master->sentence); ?><?php endif; ?>
                            </div>
                            <br>
                        </div>
                        <?php $counter++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form>

                <hr>
                <h4 class="pull-left">Inclusions:</h4>
                <p class="clearfix"></p>
                <form class="form-horizontal">
                    <?php if(count($tour_inclusion)>0): ?>
                        <?php $__currentLoopData = $tour_inclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <div class="col-sm-12 text-left"><i class="fa fa-hand-o-right"
                                                                    style="font-size:20px;color:red"></i><?php if($incl->inclusion_master_id != null): ?>
                                        <?php echo e($incl->inclusion_master->name); ?>

                                    <?php endif; ?>
                                </div>
                                <p></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </form>

                <hr>
                <h4 class="pull-left">Hotel Used <i class="fa fa-bed" style="font-size:20px;color:blue"></i></h4>
                <p class="clearfix"></p>
                <form class="form-horizontal">
                    <?php $counter = 1; ?>
                    <?php $__currentLoopData = $tour_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <div class="col-sm-12 text-left">
                                <?php if($info->hotel_master_id != null): ?> <b><?php echo e($counter); ?>

                                    . </b><?php echo e($info->hotel_master->place_master->place_name); ?> <?php echo e($info->hotel_master->hotel_name); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        <?php $counter++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form>


                <?php if($tour->vehicle_master_id != null): ?>
                    <hr>
                    <h4 class="pull-left">Transportation Description <i class="fa fa-truck"
                                                                        style="font-size:20px;color:#0e90d2"></i></h4>
                    <p class="clearfix"></p>
                    <form class="form-horizontal">
                        <div class="form-group">
                            
                            <div class="col-sm-12 text-left">
                                <?php echo e($tour->total_days); ?> Days
                                <?php echo e($tour->vehicle_master->vehicle_name); ?>, <?php echo e($tour->vehicle_comment); ?>

                            </div>
                        </div>
                    </form>
                <?php endif; ?>

                <hr>
                <h4 class="pull-left">Grand Total: &#8377 <?php echo e($grand_total); ?></h4>
                <p class="clearfix"></p>
                <form class="form-horizontal">
                    <div class="form-group">
                        
                        <div class="col-sm-12 text-left">

                        </div>
                    </div>
                </form>


                <hr>
                <h4 class="pull-left">CANCELLATION POLICY <i class="fa fa-trash" style="font-size:20px;color:red"></i>
                </h4>
                <p class="clearfix"></p>
                <form class="form-horizontal">
                    <div class="form-group">
                        
                        <?php $__currentLoopData = $policy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-12 text-left"><?php echo e($p->policy); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </form>

                <hr>

                <h4 class="pull-left">BANK DETAILS <i class="fa fa-money" style="font-size:20px;color:#007edb"></i></h4>
                <p class="clearfix"></p>
                <form class="form-horizontal">
                    <div class="form-group">
                        
                        <div class="col-sm-12 text-left">Bank Name : HDFC Bank 
                        </div>
                        <div class="col-sm-12 text-left">Name : BANJARI TOUR AND TRAVELS
                        </div>
                        <div class="col-sm-12 text-left">Account Type : Current Account
                        </div>
                        <div class="col-sm-12 text-left">Number : 50200009536204 
                        </div>
                        <div class="col-sm-12 text-left">IFSC/RTGS Code : HDFC0000224
                        </div>
                    </div>
                </form>
                <hr>
                <form class="form-horizontal">
                    <div class="form-group">
                        
                        <div class="col-sm-12 text-left">Bank Name : SBI Bank
                        </div>
                        <div class="col-sm-12 text-left">Name : BANJARI TOUR AND TRAVELS
                        </div>
                        <div class="col-sm-12 text-left">Account Type : Current
                        </div>
                        <div class="col-sm-12 text-left">Number : 35557600607 
                        </div>
                        <div class="col-sm-12 text-left">IFSC/RTGS Code : SBIN0007665
                        </div>
                    </div>
                </form>

                <form class="form-horizontal">
                    <div class="form-group">
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="col-xs-12">
                            <h4 class="text-left">With Regards <br> <?php echo e($_SESSION['user_master']->name); ?>

                                <h5 class="text-left">Mob:<?php echo e($_SESSION['user_master']->contact); ?>

                                    <br>
                                    7489333222, 7440333222 </h5>
                                <h4 class="text-left">Banjari MP Tours</h4>
                                <h5 class="text-left">Yatayat Tiraha Gurudwara Jabalpur(M.P.) <br>
                                    www.mptourpackages.com</h5></h4>
                            <h5 class="text-left"><p></p></h5>
                        </div>
                    </div>
                </form>
                
                
                
                
                
                
                
                <p class="clearfix"></p>

            </div>
        </div>
    </div>
</div>
<br/><br/>


<script>
    $(document).ready(function () {

        $('#printPdf').click(function () {
            $(this).hide();
            var pdf = new jsPDF('landscape');
            pdf.addHTML($('body')[0], function () {
                pdf.save('BANJARI_ITINERARY.pdf');
            });
        });
    });
</script>
</body>
</html>
