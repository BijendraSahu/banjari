<?php $__env->startSection('title','Lead Lists'); ?>

<?php $__env->startSection('head'); ?>
    <style>
        .notifyLinks {
            margin-top: 0 !important;
        }

        .headMargin {
            margin-bottom: 10px !important;
        }

        .notifyRed {
            background-color: #d9534f !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="bg-success text-center">Lead List</h3><p class="clearfix"></p>
    <div>
        <div class="form-group">
            <div class="col-md-12">
                <div class="panel panel-body panel-danger">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="h5 pull-left"><strong>Filter Table Records:</strong></div>
                    
                    
                    
                    
                    
                    
                    

                    
                    <div class="btn-group pull-right" data-toggle="buttons">
                        <label class="btn btn-default notifyLinks active"
                               onclick="window.location.href='<?php echo e(url('lead/1/filter')); ?>'" id="1">
                            <input type="radio" name="filter" id="1" value="all"/>All
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(1)); ?></span>
                        </label>
                        <label class="btn btn-default notifyLinks"
                               onclick="window.location.href='<?php echo e(url('lead/6/filter')); ?>'" id="6">
                            <input type="radio" name="filter" id="6" value="fresh"/>Fresh
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(6)); ?></span>
                        </label>
                        
                        
                        
                        
                        <label class="btn btn-default notifyLinks"
                               onclick="window.location.href='<?php echo e(url('lead/3/filter')); ?>'" id="3">
                            <input type="radio" name="filter" id="3" value="followup"/>Follow up
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(3)); ?></span>
                        </label>
                        <label class="btn btn-default notifyLinks"
                               onclick="window.location.href='<?php echo e(url('lead/4/filter')); ?>'" id="4">
                            <input type="radio" name="filter" id="4" value="converted"/>Converted
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(4)); ?></span>
                        </label>

                        <label class="btn btn-default notifyLinks"
                               onclick="window.location.href='<?php echo e(url('lead/5/filter')); ?>'" id="5">
                            <input type="radio" name="filter" id="5" value="completed"/>Completed
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(5)); ?></span>
                        </label>

                        <label class="btn btn-default notifyLinks"
                               onclick="window.location.href='<?php echo e(url('lead/7/filter')); ?>'" id="7">
                            <input type="radio" name="filter" id="7" value="not_interested"/>Not Interested
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(7)); ?></span>
                        </label>
                        <label class="btn btn-default notifyLinks"
                               onclick="window.location.href='<?php echo e(url('lead/8/filter')); ?>'" id="8">
                            <input type="radio" name="filter" id="8" value="not_interested"/>Today Followup
                            <span class="badge notifyRed"><?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount(8)); ?></span>
                        </label>
                    </div>
                    

                </div>
            </div>
            <div class="col-md-2">
                <div>
                    
                    
                    

                    
                    
                </div>
            </div>
        </div>

    </div>
    <p class="clearfix"></p>
    <p class="clearfix"></p>
    <div>
        <div id="leadTable">
            <table id="" class="table-bordered" cellspacing="0" width="100%">
                <thead>
                <tr class="bg-info">
                    <th class="text-center">Id#</th>
                    <th class="text-center">Enquiry#</th>
                    <th class="text-center">Category</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Contact Info</th>
                    <th class="text-center">Created On</th>
                    <th class="text-center">Last Visited</th>
                    <th class="text-center">Next Followup Date</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Allocated To</th>
                    <th class="text-center">Operations</th>
                </tr>
                </thead>
                <tbody>
                <?php $counter = 1; ?>
                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e(($item->is_completed == 1 && $item->is_converted == 1) ? 'bg-success' : ''); ?> text-center">
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->enquiry_master->full_enquiry_no); ?></td>
                        <td><?php if($item->enquiry_master->enquiry_category_id != null): ?><?php echo e($item->enquiry_master->enquiry_category->category_name); ?><?php else: ?>
                                - <?php endif; ?></td>
                        <td title="Remark- <?php echo e($item->enquiry_master->any_requirement); ?>"><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->contact); ?>, <?php echo e($item->email); ?>

                            , <?php echo e(is_null($item->address)? " - " : $item->address); ?></td>
                        <td><?php echo e(($item->created_date == null)? " - " :  date_format(date_create($item->created_date),"d-M-Y h:i A")); ?></td>
                        <td><?php echo e(($item->last_visited_date == null)? " - " : date_format(date_create($item->last_visited_date), "d-M-Y")); ?></td>
                        <td><?php echo e(($item->next_followup_date == null)? " - " : date_format(date_create($item->next_followup_date), "d-M-Y")); ?></td>
                        <td><?php echo e(($item->lead_status_id == null)? " - " : $item->lead_status->status); ?></td>
                        <td><?php echo e(($item->user_master_id != null)? $item->user_master->name :  " - "); ?></td>

                        <td id="<?php echo e($item->id); ?>">
                            <?php if($item->is_completed == 0 & $role_master_id == 1): ?>
                                <a href="#" class="btn-sm btn-danger btn-xs glyphicon glyphicon-eye-close delete_lead"
                                   title="Close Lead" onclick="close_lead(this);"></a>
                                
                                
                                
                                
                            <?php endif; ?>
                            
                            
                            <a id="<?php echo e($item->enquiry_master_id); ?>"
                               class="btn-sm btn-info btn-xs glyphicon glyphicon-eye-open view-enquiry_"
                               onclick="view_inquiry(this);" title="View Enquiry"></a>
                            <a href="<?php echo e(url('tour').'/'.$item->id.'/create'); ?>"
                               class="btn-sm btn-info btn-xs glyphicon glyphicon-plus"
                               title="Generate Tour">
                            </a>
                            <a class=" btn-sm btn-success btn-xs glyphicon glyphicon-comment view-comment"
                               title="View Communication"
                               onclick="getCommunication(<?php echo e($item->id); ?>);"><strong></strong></a>
                            <a href="#" id="<?php echo e($item->enquiry_master_id); ?>" onclick="edit_inquiry(this);"
                               class="btn-sm btn-success btn-xs edit-enquiry_ glyphicon glyphicon-pencil"
                               title="Edit Enquiry"></a>
                            
                            <?php if($_SESSION['user_master']->role_master_id == 1): ?>
                                <a href="#" class="btn-sm btn-primary assign btn-xs glyphicon glyphicon-share-alt"
                                   data-toggle="modal" onclick="assign_to_executive(this);"
                                   title="Assign To Executive"></a>
                            <?php else: ?>
                                <a href="#" class="btn-sm btn-primary btn-xs glyphicon glyphicon-cloud btnFollowUp"
                                   title="Need Followup" onclick="getfollowup(<?php echo e($item->id); ?>);">
                                </a>
                                <a href="#" class="btn-sm btn-success btn-xs glyphicon glyphicon-check btnConvert"
                                   title="Converted" onclick="getConverted(<?php echo e($item->id); ?>);">
                                </a>
                                <a href="#" class="btn-sm btn-danger btn-xs glyphicon glyphicon-cloud btnNoReponse"
                                   title="No Response" onclick="getNoResponse(<?php echo e($item->id); ?>);">
                                </a>
                            <?php endif; ?>
                            <?php if($item->is_itinerary_created == 1): ?>
                                <a href="<?php echo e(url('tour').'/'.$item->id.'/itinerary_by_lead'); ?>"
                                   class="btn-sm btn-primary btn-xs glyphicon glyphicon-italic"
                                   title="View Itinerary Tour"></a>
                            <?php endif; ?>

                            
                        </td>
                    </tr>
                    <?php $counter++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div align="center">
                <?php echo e($lead->links()); ?>

            </div>
        </div>
    </div>

    <script>
        function getLeadsbyid(dis) {
            var btnId = $(dis).attr('id');
            $('#leadTable').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
//            var btnId = this.id;
            var formData = '_token=' + $('.token').val();
            var send_to_url = '<?php echo e(url('/')); ?>' + "/lead/" + btnId + "/filter";
//            alert(send_to_url);
            $.ajax({
                type: "get",
                contentType: "application/json; charset=utf-8",
                url: send_to_url,
//                data: '{"formData":"' + formData + '"}',
                data: {pageno: 20, btn: btnId},
                beforeSend: function () {
                    $('#leadTable').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
                },
                success: function (data) {
                    $("#leadTable").html(data);
                },
                error: function (xhr, status, error) {
                    //alert('Error occurred');
                    $("#leadTable").html(xhr.responseText);
                }
            });
        }


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </script>
    <script>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


        function getCommunication(dis) {
            $('#myModal').modal('show');
            $('.modal-title').html('Communication Process');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = dis;
            var editurl = '<?php echo e(url('/')); ?>' + "/lead/" + id + "/add";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
                    $('.modal-body').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }

        function assign_to_executive(dis) {
            $('#myModal').modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#myModal .modal-title').html('Assign To Executive');
            var id = $(dis).parent().attr('id');
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_cLeadAssgn')); ?>",
                data: '{"data":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Internet connection failed...Please refresh the page again");
                }
            });
        }

        function edit_inquiry(dis) {
            $('#myModal').modal('show');
            $('.modal-title').html('Edit Enquiry');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/enquiry/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
//                $('.modal-body').html(xhr.responseText);
                    $('.modal-body').html("Internet connection failed...Please refresh the page again");

                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }

        function view_inquiry(dis) {
            $('#myModal').modal('show');
            $('.modal-title').html('View Enquiry Details');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/enquiry/" + id;
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
//                $('.modal-body').html(xhr.responseText);

                    $('.modal-body').html("Internet connection failed...Please refresh the page again");
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }

        function close_lead(dis) {
            $('#myModal').modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = $(dis).parent().attr('id');
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_clsLead')); ?>",
                data: '{"data":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Technical Error Occurred");
                }
            });
        }

        $(document).ready(function () {
            var table = $('#dataTable').DataTable({
                "columnDefs": [
                    {"width": "20px", "targets": 0}
                ],
                "order": [[0, "desc"]]
            });

            $('.datatable-col').on('keyup change', function () {
                table.column($(this).attr('id')).search($(this).val()).draw();
            });
        });

        function getfollowup(dis) {
            $("#myModal").modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = dis;
            $.ajax({
                type: "post",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gflwupfrm')); ?>",
                data: '{"id":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Error Occurred");
                }
            });
        }

        //    $(".btnConvert").click(function () {
        function getConverted(dis) {
            $("#myModal").modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = dis;
            $.ajax({
                type: "post",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gCnvtFrm')); ?>",
                data: '{"id":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Error Occurred");
                }
            });

        }

        //    $(".btnNoReponse").click(function () {
        function getNoResponse(dis) {
            $("#myModal").modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var id = dis;
            $.ajax({
                type: "post",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gNRF')); ?>",
                data: '{"id":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Internet connection failed...Please refresh the page again");
//                $('.modal-body').html("Error Occurred");
                }
            });
        }

    </script>



    <input type="hidden" id="btn_id" value="<?php echo e($btn); ?>"/>
    <input type="hidden" id="pageno" value="<?php echo e($pageno); ?>"/>
    <input type="hidden" id="total" value="<?php echo e(\App\Http\Controllers\LeadMaster\LeadMasterController::getCount($btn)); ?>"/>
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>