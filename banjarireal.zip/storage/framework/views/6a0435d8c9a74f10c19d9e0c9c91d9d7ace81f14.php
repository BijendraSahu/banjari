<div class="row">
    <div class="col-md-12">
        <div class="thumbnail">
            <div class="caption">
                
                
                
                
                <h3 class="bg-info text-center">Selected Day Description</h3>
                <p class="clearfix"></p>
                <h5><b>DAY:</b>
                    <?php if($tour_info->sentence_master_id != null): ?>  <?php echo e($tour_info->sentence_master->sentence); ?>

                    <?php endif; ?>
                </h5>
                <hr>
                <?php if($tour_info->hotel_master_id != null): ?>
                    <h3 class="text-center">HOTEL:
                        <?php echo e($tour_info->hotel_master->hotel_name); ?>

                    </h3>
                    <table id="dataTable" class="display table">
                        <thead>
                        <tr class="bg-info">
                            <th>Room Type & Inclusion</th>
                            <th>Room Rate</th>
                            <th>No of Room Use</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tour_event_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td><?php echo e($event->hotel_info->room_type); ?></td>
                                <td><i class="fa fa-inr"></i> <?php echo e($event->hotel_info->rate); ?></td>
                                <td><?php echo e($event->room_count); ?></td>
                                <td><i class="fa fa-inr"></i> <?php echo e($event->hotel_info->rate*$event->room_count); ?></td>
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>














































