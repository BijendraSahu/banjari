





<?php if(count($lists)>0): ?>
    <table id="dataTable" class="display table">
        <thead>
        <tr class="bg-info">
            <th>Option</th>
            <th>Select Sentence</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><input type="checkbox" value="<?php echo e($list->id); ?>" name="sentence[]"/></td>
                <td><?php echo e($list->sentence); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div role='alert' id='alert' class='alert alert-danger'>Sentence not available for selected location</div>
<?php endif; ?>