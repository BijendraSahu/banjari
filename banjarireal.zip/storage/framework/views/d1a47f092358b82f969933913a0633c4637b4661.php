<?php $__env->startSection('title','Create Event'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .bigdropdown {
            width: 100% !important;
        }
    </style>
    <h3 class="heading bg-success">Create Tour Event</h3>
    <hr/>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <?php echo Form::open(['url' => 'itinerary', 'class' => 'form-horizontal', 'id'=>'itinerary']); ?>

    <div class="container-fluid">
        <div class="col-sm-12">
            <h3 class="bg-info text-center">Basic Info</h3>
            <p class="clearfix"></p>
            <div class='form-group'>
                <?php echo Form::label('name', 'Pickup From*', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-5'>
                    <?php echo Form::text('tour_info_id', $id, ['class' => 'form-control hidden input-sm required', 'placeholder'=>'Tour Name']); ?>

                    <?php echo Form::select('pickup_from_id', $places, null,['class' => 'typeDD bigdropdown', 'id'=>'pickup_from_id']); ?>

                </div>
                <div class='col-sm-5'>
                    <?php echo Form::text('pickup_from_text', null, ['class' => 'form-control input-sm pickupfromtext', 'placeholder'=>'Optional Text', 'id'=>'pickup_from_text']); ?>

                </div>
            </div>

            <div class='form-group'>
                <?php echo Form::label('name', 'Transfer To*', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-5'>
                    <?php echo Form::select('transfer_to_id', $places, null,['class' => 'typeDD bigdropdown', 'id'=>'transfer_to_id']); ?>

                </div>
                <div class='col-sm-5'>
                    <?php echo Form::text('transfer_to_text', null, ['class' => 'form-control input-sm transfertotext', 'placeholder'=>'Optional Text']); ?>

                </div>
            </div>


            <div class='form-group'>
                <?php echo Form::label('name', 'Full Day*', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-5'>
                    <?php echo Form::select('full_day_inclusion_id', $inclusions, null,['class' => 'typeDD bigdropdown', 'id'=>'full_day_inclusion_id']); ?>

                </div>
                <div class='col-sm-5'>
                    <?php echo Form::text('full_day_text', null, ['class' => 'form-control input-sm', 'placeholder'=>'Optional Text']); ?>

                </div>
            </div>


            <div class='form-group'>
                <?php echo Form::label('name', 'Night Stay*', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-5'>
                    <?php echo Form::select('night_stay_id', $places, null,['class' => 'typeDD bigdropdown', 'id'=>'night_stay_id']); ?>

                </div>
                <div class='col-sm-5'>
                    <?php echo Form::text('night_stay_text', null, ['class' => 'form-control input-sm', 'placeholder'=>'Optional Text']); ?>

                </div>
            </div>
            <div class='form-group'>
                <?php echo Form::label('other_text', 'Other Text', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-10'>
                    <?php echo Form::text('other_text', null, ['class' => 'form-control input-sm', 'placeholder'=>'Other Text']); ?>

                </div>
            </div>
        </div>
        <div class="col-sm-12">
            <h3 class="bg-info text-center">Other Info</h3>
            
            
            
            
            
            
            
            
            
            
            
            
            <div class="form-group">
                <?php echo Form::label('hotel_master_id', 'Hotel', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-9'>
                    <?php echo Form::select('hotel_master_id', $hotels, null,['class' => 'typeDD bigdropdown hotel-dd', 'id'=>'hotel_master_id']); ?>

                </div>
            </div>
            
            
            
            
            
            
            <div class='form-group'>
                <?php echo Form::label('hotel_info_id', 'Select Rooms', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-10'>
                    <div id='chkBoxContainer'>

                    </div>
                </div>
            </div>

        </div>
        <div class='form-group'>
            <div class='col-sm-offset-3 col-sm-6'>

                <input class="floatright btn btn-sm btn-primary btnSubmit btn-block" type="submit" value="Submit" />
                
                        
                            
                
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

    

    
    <script>
        $(function() {
            $('form#itinerary').submit(function() {
                var c = confirm("Are you sure to continue?");
                return c;
            });
        });
        $(function () {
            $(".typeDD").select2({
//            placeholder: "SELECT IMEI",
                dropdownAutoWidth: 'true',
                width: 'auto',
                cache: true
            });
        });

        $(document).ready(function () {
            $(".hotel-dd").val('0');

        });

        $(document).on('focus', '.pickupfromtext', function () {
            $(this).autocomplete({
                source: '<?php echo e(url('gpdetail')); ?>',
                minLength: 1,
                autoFocus: true,
            });
        });

        $(document).on('focus', '.transfertotext', function () {
            $(this).autocomplete({
                source: '<?php echo e(url('transfersearch')); ?>',
                minLength: 1,
                autoFocus: true,
//                select: function (e, ui) {
//                    id_arr = $(this).attr('id');
//                    id = id_arr.split("_");
//                    $('#itemName_' + id[1]).val(ui.item.item_name);
//                }
            });
        });

        
    
    
    
    
    
            
            
                
                
                
                
                
                    
                    
                    
                    
                    
                        
                    
                    
                
                
                    
                
            
    
        

    $(".hotel-dd").change(function () {
            var id = $("#hotel_master_id").val();
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_groom')); ?>",
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#chkBoxContainer').html(data);
                },
                error: function (xhr, status, error) {
                    alert('xhr.responseText');
                }
            });
        });
        $(function () {
            $('.dtp').datepicker({
                format: "dd-MM-yyyy",
//            maxViewMode: 5,
                todayBtn: "linked",
                daysOfWeekHighlighted: "0",
                autoclose: true,
                todayHighlight: true
            });
        });
        //        $(function() {
        //            $('#type1').hide();
        //            $('#type2').hide();
        //            $('#category').change(function(){
        //                if($("#category").val() == 'Transportation') {
        //                    $('#type2').show();
        //                    $('#type1').hide();
        //                } else {
        //                    $('#type1').show();
        //                    $('#type2').hide();
        //                }
        //            });
        //        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>