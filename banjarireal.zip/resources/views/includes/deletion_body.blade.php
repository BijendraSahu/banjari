<script>
    $('#myModal .modal-title').html('Confirm Deletion');
    //    $('#modelBtn').html('<button type="submit" class="btn btn-success" id="btnDelete"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span>Confirm</button>');
</script>
<div class="container">
    <h4>Are You Sure</h4>
    <button type="button" name="btnDelete" id="btnDelete" class="btn btn-danger">Delete Record</button>
</div>