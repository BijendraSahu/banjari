<select name="ddExpenseType" id="ddExpenseType">
    <option value="0">SELECT</option>
    <option value="1">SALARY</option>
    <option value="2">ADVANCE_SALARY</option>
    <option value="3">ON_SITE_EXPENSE</option>
    <option value="4">WELLFARE_FUND</option>
    <option value="5">BONUS_FUND</option>
</select>