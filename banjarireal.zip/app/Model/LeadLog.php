<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LeadLog extends Model
{
    protected $table = 'lead_log';
    public $timestamps = false;
}
