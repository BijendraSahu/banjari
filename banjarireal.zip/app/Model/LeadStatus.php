<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LeadStatus extends Model
{
    protected $table = 'lead_status';
    public $timestamps = false;
}
